<?php

namespace App\Filament\Superadmin\Resources\CafeRestaurantResource\Pages;

use App\Filament\Superadmin\Resources\CafeRestaurantResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCafeRestaurant extends CreateRecord
{
    protected static string $resource = CafeRestaurantResource::class;
}
